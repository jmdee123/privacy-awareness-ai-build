/**
 * SCORM 2004 4th Edition API Wrapper
 * Privacy at Work — Australian Privacy Awareness
 *
 * Exposes a global SCORM object with:
 *   SCORM.init()       — call on page load (auto-called)
 *   SCORM.complete()   — call when learner reaches completion screen
 *   SCORM.setScore(n)  — optional: pass score 0-100
 *   SCORM.terminate()  — call on window unload (auto-called)
 */

var SCORM = (function () {
  'use strict';

  var _api    = null;
  var _ready  = false;
  var _debug  = false; // set true to log to console

  function log(msg) {
    if (_debug) console.log('[SCORM]', msg);
  }

  // ── Locate the SCORM 2004 API ─────────────────────────────────
  function findAPI(win) {
    var attempts = 0;
    while (!win.API_1484_11 && win.parent && win.parent !== win && attempts < 10) {
      win = win.parent;
      attempts++;
    }
    return win.API_1484_11 || null;
  }

  function getAPI() {
    var api = findAPI(window);
    if (!api && window.opener) api = findAPI(window.opener);
    return api;
  }

  // ── Core calls ────────────────────────────────────────────────
  function init() {
    _api = getAPI();
    if (!_api) {
      log('API not found — running outside LMS');
      return false;
    }
    var result = _api.Initialize('');
    _ready = (result === 'true' || result === true);
    log('Initialize: ' + result);

    if (_ready) {
      // Set initial status
      _api.SetValue('cmi.completion_status', 'incomplete');
      _api.SetValue('cmi.success_status',    'unknown');
      _api.SetValue('cmi.exit',              'suspend');
      _api.SetValue('cmi.session_time',      'PT0S');
      _api.Commit('');
    }
    return _ready;
  }

  function complete() {
    if (!_api || !_ready) {
      log('complete() called but API not ready');
      return;
    }
    _api.SetValue('cmi.completion_status', 'completed');
    _api.SetValue('cmi.success_status',    'passed');
    _api.SetValue('cmi.progress_measure',  '1');
    _api.SetValue('cmi.exit',              'normal');
    _api.Commit('');
    log('Completion recorded');
  }

  function setScore(raw, min, max) {
    if (!_api || !_ready) return;
    min = min !== undefined ? min : 0;
    max = max !== undefined ? max : 100;
    var scaled = (raw - min) / (max - min);
    _api.SetValue('cmi.score.raw',    String(raw));
    _api.SetValue('cmi.score.min',    String(min));
    _api.SetValue('cmi.score.max',    String(max));
    _api.SetValue('cmi.score.scaled', scaled.toFixed(4));
    _api.Commit('');
    log('Score set: ' + raw + '/' + max + ' (scaled: ' + scaled.toFixed(4) + ')');
  }

  function suspend() {
    if (!_api || !_ready) return;
    _api.SetValue('cmi.exit', 'suspend');
    _api.Commit('');
  }

  function terminate() {
    if (!_api || !_ready) return;
    _api.Terminate('');
    _ready = false;
    log('Terminated');
  }

  function getValue(key) {
    if (!_api || !_ready) return '';
    return _api.GetValue(key);
  }

  function setValue(key, value) {
    if (!_api || !_ready) return;
    _api.SetValue(key, value);
    _api.Commit('');
  }

  // ── Auto init / terminate ─────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.addEventListener('beforeunload', function () {
    if (_ready) {
      // If not already completed, suspend
      var status = _api ? _api.GetValue('cmi.completion_status') : '';
      if (status !== 'completed') suspend();
      terminate();
    }
  });

  return {
    init:      init,
    complete:  complete,
    setScore:  setScore,
    suspend:   suspend,
    terminate: terminate,
    getValue:  getValue,
    setValue:  setValue,
  };

}());
